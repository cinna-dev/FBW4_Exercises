//Log to console
console.log('Hello World');
console.log(123);
console.log(false);
let greeting = 'Hi';
console.log(greeting);
console.log([1,2,3,4,5]);
console.log({a:1,b:2});
console.table({a:1,b:2});// puts out a table
console.table([1,2,3,4,5]);
//console.error('This is some Error');
//console.warn('Whis is some warning');
console.clear();// this clears your console results.

console.time('scriptTime') //start counting time 
console.log('Hello World');
console.log('Hello World');
console.log('Hello World');
console.log('Hello World');
console.log('Hello World');
console.log('Hello World');
console.log('Hello World');
console.log('Hello World');
console.log('Hello World');
console.timeEnd('scriptTime')//ends counting time //naming needs to be the same with the beginning
/*
For 
Muli 
line 
comments
*/
