/* 
let exp = value;
switch (exp){
    case value1:
        do statement 1
        break;
    case value2:
        do statement 2
        break;
    ...
    default
        so something else
}
*/