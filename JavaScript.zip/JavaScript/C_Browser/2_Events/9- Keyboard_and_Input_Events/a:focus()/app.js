const btnTry = document.getElementById('try')
btnTry.addEventListener('click',focusMethod);

function focusMethod(){
    document.getElementById('inpt').focus()
}