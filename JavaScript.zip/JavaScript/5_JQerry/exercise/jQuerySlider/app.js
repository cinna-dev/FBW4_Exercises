$('.img').fadeOut(1)
console.log($('.img')[0])
$('.img')[0].fadeIn(1)
$('#slider').on('click', function(e){    
    if(e.target.id == 'leftButton'){
        $
    }
})