function closestToZero(arr){
  let tempMaxName= '';
  let tempMax = 0;
  for(i=0; i < arr.length; i++){
    if(arr[i].distance > 0){
      tempMax = arr[i].distance;
      tempMaxName = arr[i].name;
    }else if(arr[i].distance === 0){
      return arr[i].name;
    }
  }
  for(j=0; j < arr.length; j++){
    if(arr[j].distance < tempMax){
      tempMax = arr[j].distance;
      tempMaxName = arr[j].name;
    }
  }
  
    return tempMaxName;
}

let person1 ={
  name: 'peter',
  distance: 500
}
let person2 ={
  name: 'julia',
  distance: 124
}
let person3 ={
  name: 'mike',
  distance: 56
}
let person4 ={
  name: 'carl',
  distance: 100
}


let personArray = [person1, person2, person3, person4];
console.log(closestToZero(personArray));