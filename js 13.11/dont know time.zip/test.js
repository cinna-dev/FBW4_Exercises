function mobileNumberPrice(num, bDay){
    let price = 39;
    let numS = num.toString();
    bDay = bDay.replace(/-/g,'')
    console.log(bDay)
    let condition = 'standart';
    
    if(numS.length < 8){
        return `this is not a number`
    }else{

        let numArray =[];
        for(j=0;j<numS.length;j++){
        let temp = 0;
        for(i=j;i<numS.length;i++){
            if(temp > 7){
            price += 100;
            condition = 'Gold';}
            else if(numS[j] === numS[i] && temp === 0){
                temp++;
            }else if(numS[j] === numS[i] && temp === 1){
                numArray.push(numS[j])
                temp++;
            }
        }
       }
       if(numArray.length == 4){
            price += 50;
            condition = 'Silver';
       }else if(numS.includes(bDay)){
        price += 200;
        condition = 'Platin';
        }
        
      console.log(numArray) 
    }
    
   return `you have a ${condition} phone number is and cost ${price} `
}

let phoneNumber = 22334457;
phoneNumber = 24031987;
phoneNumber = 22222222;
const costumerBirthday = '24-03-1987'
console.log(mobileNumberPrice(phoneNumber, costumerBirthday))
