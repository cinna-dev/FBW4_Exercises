function closestToZero(arr){
  let tempMax = 0;
  let tempMin = 0;
  for(i=0; i < arr.length; i++){
    if(arr[i] > 0){
      tempMax = arr[i];
    }else if( arr[i] < 0){
      tempMin = arr[i];
    }else{
      return 0;
    }
  }
  for(j=0; j < arr.length; j++){
    if(arr[j] > 0 && arr[j] < tempMax){
      tempMax = arr[j];
    }else if(arr[j] < 0 && arr[j] > tempMin){
      tempMin = arr[j]
    }
  }
  tempMin = -(tempMin);
  if(tempMin < tempMax){
    return tempMin
  }else{return tempMax}
}




let numArray = [-2,-1,3,-23,0,2,4,5,6,7,8,9,11,233,-464,34]
let test = []
console.log(closestToZero(test))
