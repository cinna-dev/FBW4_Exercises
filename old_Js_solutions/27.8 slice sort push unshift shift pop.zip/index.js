let arr = ['B','A','D','C',1,2,3]
// .slice = copys arrays
let temp = arr.slice() 
// is bringing the array in order to : numbers, capital alphabet, lower case alphabet
temp.sort()
// push to new last index
temp.push('F')
// adds to first index
temp.unshift(3)
// removes first item
temp.shift()
// removes the last item        
temp.pup() 
console.log(temp)



function delMinNum(arr){
let temp =[]
arr.sort()
arr.pop()
arr.push(temp)
return temp

}



let arrNum = [1,2,3]
let outPut = delMinNum(arrNum)
console.log(outPut)