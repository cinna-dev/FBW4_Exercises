let clothing = ['shoes','shirts','socks','swearers']
let pos = 0

clothing.forEach(function(item, index){
if(item == 'shirts'){
  pos = index
  }
 }
 )
console.log(pos)