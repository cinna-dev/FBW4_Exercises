let clothing = ['shoes','chirts','socks','swearers']

clothing.forEach(function(item, index){
  console.log(item, index)
  
 })
//  slice(startingpoint, number of sliced items)
 clothing.splice(0,2)
 console.log(clothing)