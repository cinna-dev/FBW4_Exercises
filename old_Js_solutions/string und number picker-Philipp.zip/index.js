

function pickStrings(arr1){
 let  temp = [];
  arr1.forEach(function(item){
   if(typeof item == 'string'){ 
    temp.push(item); 
    }
    
}
)
return temp;
}

function pickNumbers(arr1){
 let  temp = [];
  arr1.forEach(function(item){
   if(typeof item == 'number'){ 
    temp.push(item); 
    }
    
}
)
return temp;
}

let inputArray = ['Safwan','Stefan','Jay',1,2,3];

let outputArray1 = pickStrings(inputArray)
let outputArray2 = pickNumbers(inputArray)
console.log(outputArray1);
console.log(outputArray2);
