

function pickStrings(arr1){
 let  temp1 = [];
 let temp2  = [];
  arr1.forEach(function(item){
   if(typeof item == 'string'){ 
    temp1.push(item); 
    }
    else{temp2.push(item);}
}
)
temp0 = ['Strings= '+temp1 , 'Numbers= '+temp2];
return temp0;
}

// function pickNumbers(arr1){
//  let  temp = [];
//   arr1.forEach(function(item){
//    if(typeof item == 'number'){ 
//     temp.push(item); 
//     }
    
// }
// )
// return temp;
// }

let inputArray = ['Safwan','Stefan','Jay', 1, 2, 3];

let outputArray = pickStrings(inputArray)
// let outputArray2 = pickNumbers(inputArray)
console.log(pickStrings(inputArray));

