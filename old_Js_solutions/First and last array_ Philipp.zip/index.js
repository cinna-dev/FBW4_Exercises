let fruits = ["Mango","apple","Strawberry","banana"];


function firstLast(array){
  console.log(array[0] , array[array.length-1]);
}

firstLast(fruits);