var inpMonth="july";
var inpDay=26;

var zodiacSign;

if(inpMonth === "january" && inpDay >= 20 || inpMonth === "februray" && inpDay <= 18 ){
  zodiacSign="Aquaris";
}
if(inpMonth === "februray" && inpDay >= 19 || inpMonth === "march" && inpDay <= 20 ){
  zodiacSign="Pisces";
}
if(inpMonth === "march" && inpDay >= 21 || inpMonth === "april" && inpDay <= 19 ){
  zodiacSign="Aries";
}
if(inpMonth === "april" && inpDay >= 20 || inpMonth === "may" && inpDay <= 20 ){
  zodiacSign="Taurus";
}
if(inpMonth === "may" && inpDay >= 21 || inpMonth === "June" && inpDay <= 20 ){
  zodiacSign="Gemini"; 
}
if(inpMonth === "june" && inpDay >= 21 || inpMonth === "july" && inpDay <= 22 ){
  zodiacSign="Cancer";
}
if(inpMonth === "july" && inpDay >= 23 || inpMonth === "august" && inpDay <= 22 ){
  zodiacSign="Leo";
}
if(inpMonth === "september" && inpDay >= 23 || inpMonth === "octorber" && inpDay <= 22 ){
  zodiacSign="Libra";
}
if(inpMonth === "octorber" && inpDay >= 23 || inpMonth === "november" && inpDay <= 21 ){
  zodiacSign="Scorpio";
}
if(inpMonth === "november" && inpDay >= 22 || inpMonth === "december" && inpDay <= 21 ){
  zodiacSign="Sagittarius";
}
if(inpMonth === "december" && inpDay >= 22 || inpMonth === "january" && inpDay <= 19 ){
  zodiacSign="Capricorn";
}


if(zodiacSign != undefined){console.log("Your Horoscope is: "+zodiacSign)}
else{console.log("Error : Check the spelling of your Mounth Input and make sure it is written lower case. ")};