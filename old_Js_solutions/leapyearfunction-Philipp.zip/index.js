function leapYear(array){
  let leapYearArr = [];
  array.forEach(function(item){
    if((item % 4 === 0 && item % 100 !== 0 ) || (item % 4 === 0 && item % 100 === 0 && item % 400 === 0)){
      leapYearArr.push(item)
      }
    }
  )
return leapYearArr;
}

let arrayYears = [1998, 2012, 2000, 2004, 2009, 2019];
let arrayLeapyears = leapYear(arrayYears);
console.log(arrayLeapyears);