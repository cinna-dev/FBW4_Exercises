function prefixApplier(arr1, strg){
 let  arr2 = [];
  arr1.forEach(function(item){
    arr2.push(strg +' '+ item);
}
)
return arr2;
}

let prefix = 'Mr.';
let inputArray = ['Safwan','Stefan','Jay'];

let outputArray = prefixApplier(inputArray, prefix);
console.log(outputArray);