//let array =[1,2, "dog","cat","mouse"];
//console.log(array);

// let fruits =["apple","Banana"];
// console.log(fruits);
// console.log(fruits.length);




// let arrNumbers=[1,2,3,4,5,6,7,8,9,10,11];
// let fruits =["apple","Banana"];

// function checklenght(array){
//   if(array.length>10){
//     console.log("Very long array");
//   }
//   else{
//     console.log("Normal array");
//   }
// }
// checklenght(arrNumbers);



// let fruits = ["Mango","apple","Strawberry","banana"];


// function firstLast(array){
//   console.log(array[0] , array[array.length-1]);
// }

// firstLast(fruits);



// let fruits = ["Mango","apple","Strawberry"];

// fruits.forEach(function(item){
//   console.log(item)
// })



// let array = [1,2,3,4,5,6]

// array.forEach(
//   function(item){
//   console.log(item*item)
//   }
// )

// let fruits = ['Apple','Banana'];
// let newFruits = ['Mango','Strawberry'];

// fruits.forEach(function(item){
//   newFruits.push(item);
// })
// console.log(newFruits);




// let numbers = [2,4,7];
// let evenNumbers = [];

// numbers.forEach(function(item){
//   if(item%2 == 0)
//   {evenNumbers.push(item);}
// })

// console.log(evenNumbers);



// let numbers = [2,4,7];
// function giveMeEvenArray(arr1){
//   let arr2 = [];
//   arr1.forEach(function(item){
//       if(item%2 == 0){
//      arr2.push(item);
//       }
//      }
//   )
// return arr2;
// }
// let evenNumbs = giveMeEvenArray(numbers);

// console.log(evenNumbs);



function leapYear(array){
  let leapYearArr = [];
  array.forEach(function(item){
    if((item % 4 === 0 && item % 100 !== 0 ) || (item % 4 === 0 && item % 100 === 0 && item % 400 === 0)){
      leapYearArr.push(item)
      }
    }
  )
return leapYearArr;
}

let arrayYears = [1998, 2012, 2000, 2004, 2009, 2019];
let arrayLeapyears = leapYear(arrayYears);
console.log(arrayLeapyears);
// 