function delMinNum(arr){
arr.sort()
arr.shift()
return arr
}
function delMaxNum(arr){
arr.sort()
arr.pop()
return arr
}


let arrNum = [2,3,1]
console.log(arrNum)

delMinNum(arrNum)
delMaxNum(arrNum)
console.log(arrNum)
// if the = input of a called function is an array. It will be the new reassigned array. Reference Var

